package ceng.ceng351.labdb;


import java.util.*; 



public class LabDB {

    private int bucketsize;
    private int globaldepth;
    private int howmanybuckets;
    private Vector<bucket> Buckets;

    
    
    
    private class bucket {
        public int localdepth;
        public Vector elements=null;

        public bucket() {
            localdepth=1;
            elements=new Vector();
        }
        public bucket(bucket a){
            localdepth=a.localdepth;
            for(int i=0;i<a.elements.size();i++){
                elements.add(a.elements.get(i));
            }
        }
        public void add(int a){
            elements.add(a);
        }
        
        
        
    }
    /*
    Directory - pointers to buckets
    Bucket - vector
    local depth - numbers
    
    
    
    
    */
    public LabDB(int bucketSize) {
        Buckets=new Vector();
        bucketsize=bucketSize;
        globaldepth=1;
        howmanybuckets=2;
        
        bucket a = new bucket();
        bucket b = new bucket();
        Buckets.add(a);
        Buckets.add(b);
        
        
    }
    private void reducesize() {
        int s=Buckets.size()/2;
        for(int i=0;i<s;i++){
            Buckets.remove(Buckets.size()-1);//TODO not sure about that
        }   
    }
    private void doublesize(){
        //System.out.println("Size duplication of the buckets, globaldepth++");
        int s=Buckets.size();
        for(int i=0;i<s;i++){
            Buckets.add(new bucket());//TODO not sure about that
            Buckets.get(Buckets.size()-1).localdepth=Buckets.get(i).localdepth;
        }   //TODONE localdepths
        
    }
    public LabDB() {
        globaldepth=1;
        
    }

    public void enter(String studentID) {   //TODONE BUT NEREDEYSE TAMAM
        if(search(studentID)!="-1") return;
        int hash=0;
        int res=0;
        if ((studentID != null) && (studentID.length() > 0)) {
            String result = studentID.replaceAll("[^0-9]", "");
            res=Integer.valueOf(result);
        }
        if(res==0){
            //System.out.println("You cannot enter 0 or no value");
            return;
        }
        int expo= (int) Math.pow(2, globaldepth);
        int bisi=res%expo;
        int d=globaldepth;
        while(true){
            if (Buckets.get(bisi).localdepth==d) break;
            d=Buckets.get(bisi).localdepth;
            bisi = (res%((int)Math.pow(2, d)));
        }
        //System.out.println("elemanin konulacagi yer="+bisi);
        if(Buckets.get(bisi).elements.size()==bucketsize){// bucket size doluysa 
            
            //TODO bir yer daha artırılmalı
            if(Buckets.get(bisi).localdepth+1 > globaldepth){
                globaldepth++;//local depth global depthi gecerse
                doublesize();
            }
            int p = (int)Math.pow(2, Buckets.get(bisi).localdepth);
            //Buckets.get(bisi).localdepth++;
            int b=bisi;
            while(b<Buckets.size()){
                Buckets.get(b).localdepth++;
                b=b+p;
            }//artması gereken hepsinin localdepthi artırıldı
            //d'deki elemanları çıkarıp tekrar sokucaz içeri, basit ama kesin hatam var //TODO
            //printLab();
            Vector tmp = null;
            tmp=new Vector();
            //System.out.println(Buckets.get(d).elements);
            //System.out.println("ads");
            while(Buckets.get(bisi).elements.size()!=0){
                //Buckets.get(d);
                //Vector vc = Buckets.get(d).elements;                
                tmp.add(Buckets.get(bisi).elements.remove( Buckets.get(bisi).elements.size()-1 ));
            }
            //System.out.println(tmp);
            //System.out.println("all of them got out in that row");
            //printLab();
            
            
            //tmp den alip tekrar eklicez;
            while(tmp.size()!=0){
                String st = "e"+tmp.get(tmp.size()-1);
                tmp.remove(tmp.size()-1);
                //System.out.println(st);
                enter( st );
            }
            enter(studentID);
            
            
            
            
            
            
            
            
            
        }
        else {     //bucket size dolu degil, devam et ekle
           // System.out.println("No problem adding "+res); 
            //printLab();
            Buckets.get(bisi).elements.add(res);
            //printLab();
        }
    }

    public void leave(String studentID) {
        if(search(studentID)=="-1"){ 
            return;
        }
        int re = Integer.valueOf(studentID.replaceAll("[^0-9]", ""));
        int res = re % ((int)Math.pow(2, globaldepth));
        int depth = Buckets.get(res).localdepth;
        res=res%(int)Math.pow(2,depth);
        int i=0;
        while(i<Buckets.get(res).elements.size()){
            if(re==(int)Buckets.get(res).elements.get(i)){
                Buckets.get(res).elements.remove(i); //eleman remove edildi simdi eger yeri bosaldiysa ayarlama zamani
                
                if(Buckets.get(res).elements.size()==0 &&  Buckets.get(res).localdepth != 1){
                    //TODO
                    int dep = (Buckets.get(res).localdepth);
                    int digeri;
                    dep--;
                    if(res==res%((int)Math.pow(2, dep))){//silinecek sira kendisine esit
                        digeri=res+(int)Math.pow(2, dep);
                        //Buckets.get(digeri).localdepth--;
                        Vector tmp= new Vector();
                        while(Buckets.get(digeri).elements.size()!=0){
                            tmp.add(Buckets.get(digeri).elements.remove(0));//TODO addition sirasi nasil olacak ONEMLIIIIIIIIIIIIII
                        }
                        while(tmp.size()!=0){
                            Buckets.get(res).elements.add(tmp.remove(0)); //MUST BE DONE    
                        }
                        //localdepthleri ayarlama zamani
                        digeri=res%(int)Math.pow(2, dep);
                        while(digeri<Buckets.size()){
                            Buckets.get(digeri).localdepth--;
                            digeri=digeri+(int)Math.pow(2, dep);
                        }
                    }
                    else{ // TODO baska durumlar da olabilir
                        digeri=res%(int)Math.pow(2, dep);
                        while(digeri<Buckets.size()){
                            Buckets.get(digeri).localdepth--;
                            digeri=digeri+(int)Math.pow(2, dep);
                        }
                    }
                }
                break;
            }
            i++;
        }
        boolean t = false;
        for(int jj=0;Buckets.size()>jj;jj++){
            if(Buckets.get(jj).localdepth==globaldepth) t = true;
        }
        if(t==false){
            reducesize();
            globaldepth--;
        }
        
        
    }

    public String search(String studentID) {
        
        int re = Integer.valueOf(studentID.replaceAll("[^0-9]", ""));
        
        int res = re % ((int)Math.pow(2, globaldepth)); // global sinirlar arasi bir deger buldum
                                                     //BUNU acaba ilk iki elemana bakarak yapsam yeterli olur muydu
        int depth = Buckets.get(res).localdepth; //oradaki localdepthe esitledim
        res=res%(int)Math.pow(2,depth);
        if(Buckets.get(res).elements.contains(re)){
            String s = Integer.toString(res,2);
            while(s.length()<globaldepth){
                s= "0" + s;
            }
            return s;
        }
            
        
        
        
        return "-1";
    }

    public void printLab() {
        int a = (int) Math.pow(2,globaldepth);
        Vector binaries=new Vector();
        for(int i=0;i<a;i++){
            String s = Integer.toString(i,2);
            while(s.length()<globaldepth){
                s= "0" + s;
            }
            binaries.add(s);
        }//binaries'e eklendi tüm veriler
        System.out.println("Global depth : "+globaldepth);
        for(int i=0;i<a;i++){
            System.out.print(binaries.get(i)+" : [Local depth:"+ Buckets.get(i).localdepth+"]");
            int k=i;
            k=k%(int)Math.pow(2, Buckets.get(i).localdepth);
            for(int j=0;j<Buckets.get(k).elements.size();j++){
               System.out.print("<e"+Buckets.get(k).elements.get(j)+">");
            }
            System.out.print("\n");
        }
        
    }
}
